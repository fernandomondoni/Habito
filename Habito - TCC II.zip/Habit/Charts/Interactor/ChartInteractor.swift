//
//  ChartInteractor.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation
import Combine

class ChartInteractor {
  
  private let remote: ChartRemoteDataSource = .shared
  
}

extension ChartInteractor {
  
  func fetchHabitValues(habitId: Int) -> Future<[HabitValueResponse], AppError> {
    return remote.fetchHabitValues(habitId: habitId)
  }
  
}
