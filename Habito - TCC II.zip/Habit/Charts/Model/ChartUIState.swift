//
//  ChartUIState.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation

enum ChartUIState: Equatable {
  case loading
  case emptyChart
  case fullChart
  case error(String)
}
