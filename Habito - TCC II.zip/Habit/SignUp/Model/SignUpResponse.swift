//
//  SignUpResponse.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation

struct SignUpResponse {
  
}
