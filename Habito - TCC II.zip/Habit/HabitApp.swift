//
//  HabitApp.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import SwiftUI

@main
struct HabitApp: App {
    var body: some Scene {
        WindowGroup {
          SplashView(viewModel: SplashViewModel(interactor: SplashInteractor()))
        }
    }
}
 
