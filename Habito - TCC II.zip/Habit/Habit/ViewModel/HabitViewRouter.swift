//
//  HabitViewRouter.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation
import Combine
import SwiftUI

enum HabitViewRouter {
  
  static func makeHabitCreateView(habitPublisher: PassthroughSubject<Bool, Never>) -> some View {
    let viewModel = HabitCreateViewModel(interactor: HabitCreateInteractor())
    viewModel.habitPublisher = habitPublisher
    return HabitCreateView(viewModel: viewModel)
  }
  
}
