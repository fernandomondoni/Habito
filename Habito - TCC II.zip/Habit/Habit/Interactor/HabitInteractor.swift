//
//  HabitInteractor.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation
import Combine

class HabitInteractor {
  
  private let remote: HabitRemoteDataSource = .shared
  
}

extension HabitInteractor {
  
  func fetchHabits() -> Future<[HabitResponse], AppError> {
    return remote.fetchHabits()
  }
  
}
