//
//  HabitCreateRequest.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation

struct HabitCreateRequest {
  
  let imageData: Data?
  let name: String
  let label: String
  
}
