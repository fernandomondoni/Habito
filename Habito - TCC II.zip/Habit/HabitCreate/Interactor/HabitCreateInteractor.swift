//
//  HabitCreateInteractor.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation
import Combine

class HabitCreateInteractor {
  
  private let remote: HabitCreateRemoteDataSource = .shared
  
}

extension HabitCreateInteractor {
  
  func save(habitCreateRequest request: HabitCreateRequest) -> Future<Void, AppError> {
    return remote.save(request: request)
  }
}
