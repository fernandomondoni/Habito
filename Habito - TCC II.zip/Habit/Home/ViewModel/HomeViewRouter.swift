//
//  HomeViewRouter.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation
import SwiftUI

enum HomeViewRouter {
  
  static func makeHabitView(viewModel: HabitViewModel) -> some View {
    return HabitView(viewModel: viewModel)
  }
  
  static func makeProfileView(viewModel: ProfileViewModel) -> some View {
    return ProfileView(viewModel: viewModel)
  }
  
}
