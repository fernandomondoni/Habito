//
//  SignInErrorResponse.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation

struct SignInErrorResponse: Decodable {
  
  let detail: SignInDetailErrorResponse
  
  enum CodingKeys: String, CodingKey {
    case detail
  }
  
}

struct SignInDetailErrorResponse: Decodable {
  
  let message: String
  
  enum CodingKeys: String, CodingKey {
    case message
  }
  
}
