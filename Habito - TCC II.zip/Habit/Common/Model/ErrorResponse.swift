//
//  ErrorResponse.swift
//  Habito
//
//  Created by Fernando Mondoni and Rodrigo Teodoro on 30/03/23.
//

import Foundation

struct ErrorResponse: Decodable {
  let detail: String
  
  enum CodingKeys: String, CodingKey {
    case detail
  }
}
